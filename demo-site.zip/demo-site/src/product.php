<?php
include 'config.php';
$id = $_GET['id'];

$product = $conn->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();

if ($_POST) {
  $author = $_POST['author'];
  $content = $_POST['content'];

  $conn->query("INSERT INTO reviews VALUES (NULL, $id, '$author', '$content')");
}
?>

<h2><?php echo $product['name']; ?></h2>
<p><?php echo $product['description']; ?></p>

<h3>Reviews</h3>

<?php
$reviews = $conn->query("SELECT * FROM reviews WHERE product_id=$id");
while ($r = $reviews->fetch_assoc()) {
  echo "<p><strong>{$r['author']}:</strong> {$r['content']}</p>";
}
?>

<h3>Add Review</h3>
<form method="POST">
  <input name="author" placeholder="Name"><br>
  <textarea name="content"></textarea><br>
  <button>Submit</button>
</form>

