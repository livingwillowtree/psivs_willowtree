<?php
$conn = new mysqli("db", "root", "root", "shop");
if ($conn->connect_error) {
    die("DB Connection failed");
}

